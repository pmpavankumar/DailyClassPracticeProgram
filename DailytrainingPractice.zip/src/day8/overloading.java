package day8;

public class overloading {
	
	void displayInfo()
	{
		System.out.println("zero paramter");
	}
	void displayInfo(int id)
	{
		System.out.println("one paramter"+ id);
	}
	void displayInfo(String name)
	{
		System.out.println("your  name"+ name);
	}
	void displayInfo(int id,String name)
	{
		System.out.println("your name"+ name);
		System.out.println("your id"+ name);
	}
	void displayInfo( String name,int id)
	{
		System.out.println("your name"+ name);
		System.out.println("your  id"+ name);
	}
	public static void main(String[] args) {
		
overloading obj= new overloading();
obj.displayInfo("sachin");
	}

}
