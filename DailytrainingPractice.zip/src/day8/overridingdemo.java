package day8;

class parent
{
	void property()
	{
		System.out.println("20 laks");
	}
	void marry()
	{
		System.out.println("preeti");
	}
}
class child extends parent
{
	@Override
	void marry()
	{
		//super.marry();
		System.out.println("you mayy karina");
	}
	void vecicle()
	{
		System.out.println("i have i20");
	}
}
public class overridingdemo {

	public static void main(String[] args) {
	
		/*child c= new child();
		c.property();
		c.marry();
        c.vecicle();
        */
        parent p= new child();
        p.property();
        p.marry();
        //p.vecicle();
	}

}
