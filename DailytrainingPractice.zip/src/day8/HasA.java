package day8;

class employee
{
	int id;
	String name;
	adress address;
	public employee(int id, String name, adress address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
class adress
{
	int doornumber;
	String streetname;
	String city;
	public adress(int doornumber, String streetname, String city) {
		super();
		this.doornumber = doornumber;
		this.streetname = streetname;
		this.city = city;
		this.adress = ad;
	}
	
	void displayemployeeinfo()
	{
		System.out.println("id "+ id);
		System.out.println("name "+ name);
		System.out.println("doornumber "+ A);
	}
}
public class HasA {

	public static void main(String[] args) {
	adress ad = new adress(232,"btm","banglore");
	employee emp = new employee(1,"rahul",ad);
	emp.displayemployeeinfo();

	}
}
