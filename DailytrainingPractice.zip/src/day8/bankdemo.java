package day8;

class bank
{
	void rateofintrest()
	{
		System.out.println("2%");
	}
	void minimumbal()
	{
		System.out.println("1000");
	}
}
class axies extends bank
{
	void rateofintrest()
	{
		//super.rateofintrest();
		System.out.println("5%");
	}
	
}
class icici extends bank
{
	void rateofintrest()
	{
		System.out.println("6%");
	}
	
}

public class bankdemo {

	public static void main(String[] args) {
		
	bank ic = new icici();
	bank ax = new axies();
	
	ic.rateofintrest();
	ax.rateofintrest();
	ic.minimumbal();
	ax.minimumbal();
	
	}

}
