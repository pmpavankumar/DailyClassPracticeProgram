package day9;

interface manager1
{
	void salary1();
}
interface employee1
{
	void salary2();
}
class demo implements manager1,employee1
{

	@Override
	public void salary1() {
		System.out.println("manager");
	}

	@Override
	public void salary2() {
	System.out.println("employee");
		
	}
		
}
public class interacedemo2 {

	public static void main(String[] args) {
	

	}

}
