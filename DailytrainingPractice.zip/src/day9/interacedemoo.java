package day9;

interface bank
{
	int rateofintrest(int percent);
	double minimumbalance(double amount);
}

class kotak implements bank
{

	@Override
	public int rateofintrest(int percent) {
		System.out.println("rayeofintrest "+percent);
		return percent;
		
	}

	@Override
	public double minimumbalance(double amount) {
		System.out.println("minimum balance"+ amount);
		return 0;
	}
	
}
/*
class sbi implements bank
{
	@Override
	public int rateofintrest(int percent) {
		System.out.println("rayeofintrest "+percent);
		return percent;
		
	}

	@Override
	public double minimumbalance(double amount) {
		System.out.println("minimum balance"+ amount);
		return 0;
}
*/


public class interacedemoo {

public static void main(String[] args) {
		
bank b = new kotak();
b.minimumbalance(3000);
b.rateofintrest(4);


	}

}
