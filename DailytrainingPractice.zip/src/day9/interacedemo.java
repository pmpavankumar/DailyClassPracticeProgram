package day9;



interface employee
{
	int loginhours=8;
	
	void designation();
}
class manager implements employee
{
	@Override
	public void designation() {
		System.out.println("i amnag the team for 4 client");
		System.out.println("my designation is manager");
		System.out.println("i work for "+ loginhours +"hour");
	}
}
class devloper implements employee
{
	@Override
	public void designation() {
		System.out.println("i amnag the team for 4 client");
		System.out.println("my designation is manager");
		System.out.println("i work for "+ loginhours +"hour");
	}	
}
	
public class interacedemo {

	public static void main(String[] args) {
		
manager m = new manager();
m.designation();
	}



	
}



