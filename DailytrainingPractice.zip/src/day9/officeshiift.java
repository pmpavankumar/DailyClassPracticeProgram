package day9;

abstract class shifttiming
{
	abstract void workingtime(int a,int b);
	void display()
	{
		System.out.println("hcl");
	}
}
class morningshift extends shifttiming
{

	@Override
	void workingtime(int a, int b) {
		System.out.println("morning shift "+a+"A.M- "+b+"P.M");
		
		
	}
	
}
class evningshifts extends shifttiming
{

	@Override
	void workingtime(int a, int b) {
		System.out.println("evg shift "+a+"P.M- "+b+"P.M");
			
		
	}
	
}
class nightshifts extends shifttiming
{

	@Override
	void workingtime(int a, int b) {
		System.out.println("night shift "+a+"P.M- "+b+"A.M");
		
	}
	
}
public class officeshiift {

	public static void main(String[] args) {
		morningshift m = new morningshift();
		evningshifts e = new evningshifts();
		nightshifts n = new nightshifts();
		m.display();
		e.display();
		n.display();
		

	}

}
