package day9;

abstract class operation
{
	abstract void numbers(int a,int b,int c);
	void display()
	{
		System.out.println("this is normal method");
	}
}

class sachin extends operation
{

	@Override
	void numbers(int a, int b, int c) {
		System.out.println(a+b+c);
	}

	
}
class rahul extends operation
{

	@Override
	void numbers(int a, int b, int c) {
	System.out.println(a-b-c);
		
	}
	
}


public class abstractdemo2 {
	public static void main(String[] args) {
		sachin s = new sachin();
		s.numbers(3,4,4);
		s.display();
		
		rahul r = new rahul();
		r.numbers(4,1,5);
		r.display();
		
		}


}
