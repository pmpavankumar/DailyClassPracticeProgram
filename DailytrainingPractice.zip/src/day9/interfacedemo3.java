package day9;

interface a
{
	
}
interface b
{
	
}
interface c
{
	
}
class x
{
	
}
class demo1 extends x implements a,b,c
{
	
}
public class interfacedemo3 {

	public static void main(String[] args) {
		
	}

}
