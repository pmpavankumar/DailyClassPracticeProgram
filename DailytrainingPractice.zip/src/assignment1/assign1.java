package assignment1;

public class assign1 {
	public static void main(String[] args)
	{
		char ch=args[0].charAt(0);
		switch(ch)
		{
		case 'R' :System.out.println("R->Red");
		break;
		case 'B' :System.out.println("B->Blue");
		break;
		case 'G' :System.out.println("G->Green");
		break;
		case 'O' :System.out.println("O->orange");
		break;
		case 'Y' :System.out.println("Y->Yellow");
		break;
		case 'W' :System.out.println("W->white");
		break;
		default :System.out.println("Invalid");
		}
	}

}
