package day7;

class Employee
{
	private int id;
	private String name;
	
	public void setid(int id)
	{
		this.id=id;
	}
	public int getid()
	{
		return id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
}
public class encapsulationdemo {

	public static void main(String[] args) {
		Employee e = new Employee();
		e.setid(2);
		System.out.println(e.getid());
	}

}
