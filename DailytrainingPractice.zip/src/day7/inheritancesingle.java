package day7;

class compose
{
	String email="ravi@gmail.com";
	String message="hello thax";
}

class SentMail extends compose
{
	String status ="deliverd";
	
	void disp()
	{
		System.out.println(email);
		System.out.println(message);
		System.out.println(status);
	}
}
public class inheritancesingle {

	public static void main(String[] args) {
		compose c=new compose();
		System.out.println(c.email);
		System.out.println(c.message);
		
		SentMail s = new SentMail();
		
		System.out.println(c.email);
		System.out.println(c.message);
		System.out.println(c.status);
	}

}
