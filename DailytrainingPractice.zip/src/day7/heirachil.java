package day7;
class Human{
void work()
{
	System.out.println("human can work");
}
void eat()
{
	System.out.println("human can eat");
}
}
class engineer extends Human
{
	
}
public class heirachil {

	public static void main(String[] args) {
		heirachil H=new heirachil();
		engineer E=new engineer();
		H.work();
		E.eat();
	}
}
