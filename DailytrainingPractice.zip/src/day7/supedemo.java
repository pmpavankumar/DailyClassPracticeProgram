package day7;

class parent1
{
	parent1(int id,String name)
	{
		System.out.println("this is partnt constructor");
		System.out.println("id "+ id +"name "+name);
	}
}
class child1 extends parent1
{
	child1(int id,String name)
	{
		super(id,name);
	System.out.println("this is child contructor");	
	}
}




public class supedemo{

	public static void main(String[] args) {
		child1 c = new child1(2,"ravi");
	}

}
