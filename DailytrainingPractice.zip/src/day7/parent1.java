package day7;
class parent
{
	parent()
	{
		System.out.println("this is pareent constructor");
	}
}
class child1 extends parent1
{
	child1()
	{
		System.out.println("this ii child constructor");
	}
}

public class parent1 {

	public static void main(String[] args) {
		child1 c = new child();
	}

}
