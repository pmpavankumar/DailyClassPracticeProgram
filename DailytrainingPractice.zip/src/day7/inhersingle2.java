package day7;

class parent
{
void parentInfo()
{
	System.out.println("i am parent my house address is btm");
	System.out.println("my contact is 00000");
}
}
class child extends parent
{
	system.out.println(" i study in bright public school");
}
public class inhersingle2 {

	public static void main(String[] args) {
		
	}

}
