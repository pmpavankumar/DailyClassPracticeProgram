package day7;
class datav1
{
	int data1;
	int data2;
	datav1(int d1,int d2)
	{
		data1=d1;
		data2=d2;
	}
}
class datav2 extends datav1
{
int data3;
int data4;
  datav2(int d1,int d2,int d3,int d4)
  {
	  super(d1,d2);
	  data3=d3;
	  data4=d4;
  }
}
class datav3 extends datav2
{
	int data5;
	int data6;
	datav3(int d1,int d2,int d3,int d4,int d5,int d6)
	{
		super(d1,d2,d3,d4);
		data5=d5;
		data6=d6;
	}
	void printValues()
	{
		System.out.println("data1= "+data1);
		System.out.println("data2= "+data2);
		System.out.println("data3= "+data3);
		System.out.println("data4= "+data4);
		System.out.println("data5= "+data5);
		System.out.println("data6= "+data6);
}
	
}

public class multilevel {

	public static void main(String[] args) {
		datav3 obj = new datav3(1,2,3,4,5,6);
		obj.printValues();
	}

}
