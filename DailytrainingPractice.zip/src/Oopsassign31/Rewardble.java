package Oopsassign31;

public class Rewardble {
	public interface Rewardable {
		
		public int rewards(double amount);

	}

}
