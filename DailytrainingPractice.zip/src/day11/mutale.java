package day11;

public class mutale {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("rahul");
		
		
	}

}
