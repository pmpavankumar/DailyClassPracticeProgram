package day11;

import java.io.IOException;

class LateException extends RuntimeException
{
	String msg;

	public LateException(String msg) {
		super(msg);
		//this.msg = msg;
		System.out.println("this a constructor in late exception class");
	}
	
}

class StudentDemo
{
	void logintime(int time) throws LateException
	{
		if(time>9)
		{
			throw new LateException ("you are absent");
		}
		else
		{
			System.out.println("you are present");
		}
	}
}

public class customeException {
	
	void disp()
	{
		System.out.println("hello");
	}

	public static void main(String[] args) throws LateException  {
		
		StudentDemo StudentDemo= new StudentDemo();
		StudentDemo.logintime(10);
		
		customeException c = new  customeException();
	
		

	}

}
