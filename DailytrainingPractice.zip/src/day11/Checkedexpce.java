
package day11;

import java.io.File;

public class Checkedexpce {
	public static void main(String[] args)
	{
		int a[]=new int[10];
		System.out.println(2/10);
		System.out.println(a[20]);
		
		File f = new File("abc.txt");
		f.createNewFile();
		
	}

}
