package day11;

public class immutableDemo {

	public static void main(String[] args) {
		int a=10;
		System.out.println("value of a"+ a);
		
		
		
		String name = "rahul";
		System.out.println(name);
		
		name.concat("dravid1");
		System.out.println(name);
		
		name = name+"dravid2";
	System.out.println(name);
	}

}
