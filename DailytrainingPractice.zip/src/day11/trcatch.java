package day11;

public class trcatch {

	public static void main(String[] args) {
		
		int num1,num2;
		try
		{
			num1=0;
			num2=10/num1;
			System.out.println(num2);
			System.out.println("hey i am at the end of try block");
		}
		catch (ArithmeticException e)
		{
			System.out.println("you should not divide number by zero");
		}
		catch (Exception e)
		{
			System.out.println("exception occured");
			
		}
		finally
		{
			System.out.println("closing statement");
		}
System.out.println("i am out of try catch block");
	}

}
