package day11;

public class Strinfdemo {

	public static void main(String[] args) {
	String s1 = "hello";
	String s3 = new String("hello");
	
	String s3 = new String("hello");
	String s4 = new String("help");
	
	
	
	//System.out.println("length od string "+s1.length());
	//System.out.println("character of specific index"+s1.charAt(2));
	}

}
