package day11;

public class throwandthrows {
	void loginTime(int time)
	{
		System.out.println("you have at "+ time);
		if(time>9)
		{
			throw new ArithmeticException("you are absent");
		}
		else
		{
			 System.out.println("you are absent");
		}
	}

	public static void main(String[] args) {
//	throw new ArithmeticException("it is throwing some exception");
	throwandthrows t = new throwandthrows();
	t.loginTime(8);
	}

}
