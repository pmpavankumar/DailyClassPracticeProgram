package day1;

import java.util.Scanner;

public class operator {
	
	public static void main(String[] args) {
		int x,y;
		x=11;
		y=(x==11)?11:10;
		System.out.println("value of y is:"+y);
		y=(x==5)?4:9;
		System.out.println("value of y is:" +y);
	}

}
