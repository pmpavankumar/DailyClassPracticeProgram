package day1;

public class incanddec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=5;
int b=2;
//System.out.println("value of a "+ a++);
//System.out.println("value of a "+ a);
System.out.println(a/b);
System.out.println(a%b);
System.out.println(b%a);
	}

}
