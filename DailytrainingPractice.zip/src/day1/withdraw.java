package day1;
import day10.monthpay

public class withdraw {
	
	public class d{

	public static void main(String[] args) {
	
	}

}
