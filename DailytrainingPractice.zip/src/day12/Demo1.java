package day12;

public class Demo1 {

	public static void main(String[] args) {
		String name="hello java";
		
		for(int i=0;i<name.length();i++)
		{
			System.out.print(name.charAt(i));
		}
	}

}
