package day12;

public class StringDemo {

	public static void main(String[] args) {
		String s="hello";
		System.out.println("length "+s.length());
		System.out.println(s.concat("java "));
		System.out.println("name is "+ s);
		
		System.out.println(s.charAt(2));
		System.out.println("sub string "+ s.substring(2));
		System.out.println("sub string start and end "+ s.substring(1,4));
		System.out.println("index"+ s.indent('e'));
		System.out.println("replace "+s.replace('1', 'j'));
		System.out.println("equals"+ s.equals("hello"));
		System.out.println("equal and ignpoore"+ s.equalsIgnoreCase("hello"));
		System.out.println(s.compareTo("hello"));
		System.out.println("d".compareTo("a"));
		System.out.println( "a".compareTo("d"));
		System.out.println( "aaff".compareTo("adfff"));
		
	
	
	}

}
