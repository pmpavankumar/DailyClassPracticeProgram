package day12;

public class Countvowels {

	public static void main(String[] args) {
	 String name = "pavan";
	 String temp=" ";
	 int count =0;
	 for(int i=0;i<name.length();i++)
	 {
		 char c=name.charAt(i);
		 if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u') 
		 {
			 count++;
		 }	

	}

}
}
