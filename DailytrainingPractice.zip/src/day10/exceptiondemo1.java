package day10;

public class exceptiondemo1 {

	public static void main(String[] args) {
	
		int a=10;
		int b=0;
		System.out.println("hello");
		System.out.println(a/b);
	
		System.out.println("thank you");
	}

}
