package day10;

public class monthpay {
	void monthly()
	{
		System.out.println("this";)
	}

}
