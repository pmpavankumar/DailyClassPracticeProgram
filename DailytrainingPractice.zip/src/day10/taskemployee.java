package day10;

public class taskemployee {

	public static void main(String[] args) {
		
	}

}
