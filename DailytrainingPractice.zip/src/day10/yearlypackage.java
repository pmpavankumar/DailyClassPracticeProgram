package day10;

public class yearlypackage {
	void yearly()
	{
		System.out.println("yearly");
	}

}
