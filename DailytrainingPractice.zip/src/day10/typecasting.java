package day10;

public class typecasting {

	public static void main(String[] args) {
	int a=128;
	
	double d=a;//implicit
	
System.out.println(d);

double d1 = 200.20;

int b=(int)d1;//explicit

byte c = (byte)a;
System.out.println(c);

short s =(short)a;
System.out.println(s);
	}
//untilm print as value up to 128 
}
