package day10;

public class wrapperdemo {

	public static void main(String[] args) {
	int a=10;
	Integer b=a;//auto boxing
	System.out.println(b);
	
	}

}
