package day3;

public class swith {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int day=2;
switch(day)
{
case 1:
	System.out.println("monday");
	break;
case 2:
	System.out.println("tue");
	break;
case 3:
	System.out.println("wed");
	break;
	default:System.out.println("invali");
	
}
	}

}
