package day3;

public class student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
