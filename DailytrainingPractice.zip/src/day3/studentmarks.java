package day3;

public class studentmarks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
