package day3;

public class arraydemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int marks[]=new int[5];
System.out.println(" sizeof array "+marks.length);
marks[1]=56;
marks[4]=70;

System.out.println(marks[0]);
System.out.println(marks[1]);
System.out.println(marks[2]);
System.out.println(marks[3]);
System.out.println(marks[4]);
	
//iterating through loop
	System.out.println("itrating throughloop");
	for(int i=0;i<marks.length;i++)
	{
System.out.println(marks[i]);
}
}
}