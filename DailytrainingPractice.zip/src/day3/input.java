package day3;
import java.util.Scanner;
public class input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan=new Scanner(System.in);
	System.out.println("enter how to scan element you want");
	int size=scan.nextInt();
	int marks[]=new int[size];
	System.out.println("size of arry"+ marks.length);
	
	for(int i=0;i<marks.length;i++)
	{
		System.out.print("enter the value of marks["+ i +"]=");
		marks[i]=scan.nextInt();
		
	}
	System.out.println();
	}

}
