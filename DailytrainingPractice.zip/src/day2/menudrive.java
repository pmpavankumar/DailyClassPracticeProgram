package day2;

public class menudrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
