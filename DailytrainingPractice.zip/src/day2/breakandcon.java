package day2;

public class breakandcon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=1;i<=10;i++)
{
	if(i>3 & i==7)
	{
		//break;
		continue;
	}
	System.out.println(i +" java");
	}
}
}
