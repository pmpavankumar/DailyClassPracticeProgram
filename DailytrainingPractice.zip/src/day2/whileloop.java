package day2;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=1;
while(a<5)
{
	System.out.println("value a "+ a);
	++a;
}
	}

}
