package day6;

class student
{
	int id;
	String name;
	static String companyName="abc college ";
}
public class staticdemo {

	public static void main(String[] args) {
		
		student ravi = new student();
		ravi.id=1;
		ravi.name="ravi kumar";
		ravi.companyName="TCS";
		
	student ramesh =new student();
	ramesh.id=2;
	ramesh.name="ramesh kumar";
	ramesh.companyName="fujitsu";
	
	student kumar = new student();
	kumar.id=2;
	kumar.name="ramesh kumar";
	kumar.companyName="hcl";
	
	System.out.println(ravi.id +" "+ravi.name +" "+student.companyName);
	System.out.println(ramesh.id +" "+ramesh.name +" "+student.companyName);
	System.out.println(kumar.id +" "+kumar.name +" "+student.companyName);	
		
	}

}
