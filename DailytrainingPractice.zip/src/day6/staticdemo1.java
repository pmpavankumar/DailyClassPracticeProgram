package day6;
class student1
{
	int id;
	String name;
	String dept;
	
	student1(int i,String n,String d)
	{
		System.out.println("constructor called");
	}
	void display()
	{
		System.out.println("id "+ id);
		System.out.println("name "+name);
	}
}

public class staticdemo1 {

	public static void main(String[] args) {
		System.out.println("hello well come to java");
		System.out.println("good morning");
	}
static 
{
	System.out.println("this is static block 2");
}
}
