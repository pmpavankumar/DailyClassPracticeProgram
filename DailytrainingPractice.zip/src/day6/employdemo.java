package day6;
class Employee
{
	//variables
	int employeeId=1;
	String name;
	String dept;
	double salary;
	
	void DisplayEmployeeDetails()
	{
		System.out.println("id is "+ employeeId);
		System.out.println("name is "+ name);
		System.out.println("dept is "+ dept);
		System.out.println("salary is "+ salary);
	}
	String checkforBounsoption()
	{
		if(salary>75000.00)
			return "you can applay for loan";
		return "you cannot applay for loan ";
	}
}

public class employdemo {

	
	public static void main(String[] args) {
		System.out.println("employee demo app");
		Employee ramesh=new Employee();
		ramesh.employeeId=123;
		ramesh.name="ramesh";
		ramesh.salary=45000.0;
		ramesh.dept="hr";
		
		ramesh.DisplayEmployeeDetails();
		//String message = ramesh.checkForLoanOption();
	//system.out
        System.out.println(ramesh.checkforBounsoption());
	}
	

}
