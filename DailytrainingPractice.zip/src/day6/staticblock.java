package day6;

public class staticblock {
	static
	{
		System.out.println("this is static block 1");
	}

	public static void main(String[] args) {
	System.out.println("hello welcome java");
	System.out.println("good morining");
	}
static 
{
	System.out.println("this is static block 2");
}
}
