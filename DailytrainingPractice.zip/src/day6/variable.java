package day6;

public class variable {
	int a=10;//gloabl variable/instant variable
	static int b=10;
	void fun1(int x)//x is a local variable 
	{
		System.out.println("value of a "+ a);
		System.out.println("value of x"+ x);
	}
	void fun2(int y)
	{
		System.out.println("value of a "+ a);
		System.out.println("value of x"+ y);
		
	}
	
	
	
	

	public static void main(String[] args) {
		variable variable = new variable();//heap aera
		
System.out.println(variable.a);
System.out.println(b);
	variable.a=45;//
	
	}

}
