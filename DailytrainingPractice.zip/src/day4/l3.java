package day4;

public class l3 {

	public static void main(String[] args) {
	int a[]= {2,3,8,6,5,19,13,7};
	int findNumber=15;
	int flag=0;
	int location=0;
	
	for(int i=0;i<a.length;i++)
	{
		if(a[i]==findNumber)
		{
			location=i+1;
			flag=1;
			break;
		}
		else
		{
			flag=0;
		}
	}
	if(flag==1)
	{
		System.out.println("the elementis found at " + location);
	}
	else
	{
		System.out.println("the element is not found" + location);
	}
	}
}
	/*
	for(int i=0;i<a.length;i++)
	{
		if(a[i]==findNumber)
		{
			System.out.println("number is found" + a[i]);
		
		}
		else
		{
			System.out.println("println is not found" + a[i]);
		}
	}
	*/
		


