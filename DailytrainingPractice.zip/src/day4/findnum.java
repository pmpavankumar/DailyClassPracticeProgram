package day4;

public class findnum {

	public static void main(String[] args) {
		int a[]= {2,8,6,5,19,13,7};
		
		int findNumber=13;
		
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==findNumber)
			{
				System.out.println("number is fund");
			}
			else
			{
				System.out.println("ele not found");
			}
		}

	}

}
