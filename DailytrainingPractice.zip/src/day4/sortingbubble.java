package day4;

public class sortingbubble {

	public static void main(String[] args) {
		int a[]= {7,4,15,12,3,9,6};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		System.out.println("after");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}

	}

}
