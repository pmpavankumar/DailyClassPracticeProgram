package day4;

public class linear2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {2,3,4,5,6,7,5,6};

int findNumber=3;
int flag=0;
int index=0;


for(int i=0;i<a.length;i++)
{
	if(findNumber==a[i])
	{
		index=i;
		flag=1;
		break;
	
	}
	else
	{
		flag=0;
	}
		if(flag==1)
		{
			System.out.println("ele found at index");
		
		}
		else
		{
			System.out.println("not foun");
		}
		}
}
	
	}

